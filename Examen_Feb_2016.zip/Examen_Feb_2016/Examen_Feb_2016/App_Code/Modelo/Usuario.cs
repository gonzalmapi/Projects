﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Examen_Feb_2016.App_Code.Modelo
{
    public class Usuario
    {
       public string email{get;set;}
    public string password { get; set; }
    }
}