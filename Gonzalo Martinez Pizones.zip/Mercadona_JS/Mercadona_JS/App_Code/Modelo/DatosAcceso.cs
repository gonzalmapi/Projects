﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mercadona_JS.App_Code.Modelo
{
    public class DatosAcceso
    {
        public String email{ get; set; }
        public String passw { get; set; }
    }
}