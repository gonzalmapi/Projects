﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Mercadona_JS.App_Code.Modelo
{
    public class DatosRegistro
    {
        public String nombre { get; set; }
        public String ape1 { get; set; }
        public String ape2 { get; set; }
        public String tipo_ID { get; set; }
        public String ID { get; set; }
        public String info { get; set; }
        public String email { get; set; }
        public String fecha { get; set; }
        public String passw { get; set; }
        public String direc { get; set; }
        public String telf { get; set; }
    }
}